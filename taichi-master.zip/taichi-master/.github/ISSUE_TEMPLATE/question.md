---
name: Ask a Question
about: Ask anything about Taichi
title: ''
labels: question
assignees: ''

---

<!--
Before asking a question, please first consider:

- Searching Google
- Searching [existing issues](https://github.com/taichi-dev/taichi/issues)
- Searching [Taichi Doc](https://docs.taichi-lang.org/)
- Searching [Taichi Forum](https://forum.taichi.graphics/)
-->

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys

import ti_build.entry

if __name__ == "__main__":
    sys.exit(ti_build.entry.main())

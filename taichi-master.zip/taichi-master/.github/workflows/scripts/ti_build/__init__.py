from .bootstrap import early_init

early_init()

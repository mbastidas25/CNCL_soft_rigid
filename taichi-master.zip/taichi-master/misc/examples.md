# More examples

<a href="https://github.com/taichi-dev/taichi/blob/master/python/taichi/examples/simulation/mpm_lagrangian_forces.py"><img src="https://github.com/taichi-dev/public_files/raw/master/taichi/lagrangian.gif" height="192px"></a>
<a href="https://github.com/taichi-dev/taichi/blob/master/python/taichi/examples/features/sparse/taichi_sparse.py"><img src="https://github.com/taichi-dev/public_files/raw/master/taichi/sparse_grids.gif" height="192px"></a>
<a href="https://github.com/taichi-dev/taichi/blob/master/python/taichi/examples/simulation/pbf2d.py"><img src="https://github.com/taichi-dev/public_files/raw/master/taichi/pbf.gif" height="192px"></a>
<a href="https://github.com/taichi-dev/taichi/blob/master/python/taichi/examples/simulation/game_of_life.py"><img src="https://github.com/taichi-dev/public_files/raw/master/taichi/game_of_life.gif" height="192px"></a>

<a href="https://github.com/taichi-dev/taichi/blob/master/python/taichi/examples/simulation/fem128.py"><img src="https://github.com/taichi-dev/public_files/raw/master/taichi/fem128.gif" height="192px"></a>
<a href="https://github.com/taichi-dev/taichi/blob/master/python/taichi/examples/simulation/mass_spring_3d.py"><img src="https://github.com/taichi-dev/public_files/raw/master/taichi/mass_spring_3d.gif" height="192px"></a>
<a href="https://github.com/taichi-dev/taichi/blob/master/python/taichi/examples/algorithm/mciso_advanced.py"><img src="https://github.com/taichi-dev/public_files/raw/master/taichi/mciso.gif" height="192px"></a>
<a href="https://github.com/taichi-dev/taichi/blob/master/python/taichi/examples/simulation/mpm3d.py"><img src="https://github.com/taichi-dev/public_files/raw/master/taichi/mpm3d.gif" height="192px"></a>

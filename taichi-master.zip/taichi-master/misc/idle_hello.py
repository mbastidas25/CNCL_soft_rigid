import taichi as ti


@ti.kernel
def func():
    pass


func()

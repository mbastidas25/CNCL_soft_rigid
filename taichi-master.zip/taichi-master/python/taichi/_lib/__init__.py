from taichi._lib.utils import ti_python_core as core

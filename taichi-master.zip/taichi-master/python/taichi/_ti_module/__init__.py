from taichi._ti_module.module import _main
